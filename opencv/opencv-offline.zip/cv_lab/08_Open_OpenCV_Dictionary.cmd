@echo off
start "" "%~dp0opencv_dictionary\OpenCV函数词典.html"

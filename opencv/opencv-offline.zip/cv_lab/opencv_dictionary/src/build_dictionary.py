"""使用当前解释器的 OpenCV 文档生成完全离线的单文件词典。"""
from pathlib import Path
import datetime
import inspect
import importlib.metadata
import json
import re
import shutil
import types
import cv2
from curated import ENTRIES, PREAMBLE

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CATEGORIES = ['读写与窗口','颜色与像素','滤波与梯度','阈值与形态学','几何变换',
              '边缘与轮廓','角点与特征','匹配与配准','标定与三维','绘图与视频','其他接口']
DOCS = {
 '读写与窗口':'https://docs.opencv.org/4.10.0/d7/dfc/group__highgui.html',
 '颜色与像素':'https://docs.opencv.org/4.10.0/d7/d1b/group__imgproc__misc.html',
 '滤波与梯度':'https://docs.opencv.org/4.10.0/d4/d86/group__imgproc__filter.html',
 '阈值与形态学':'https://docs.opencv.org/4.10.0/d4/d86/group__imgproc__filter.html',
 '几何变换':'https://docs.opencv.org/4.10.0/da/d54/group__imgproc__transform.html',
 '边缘与轮廓':'https://docs.opencv.org/4.10.0/d3/dc0/group__imgproc__shape.html',
 '角点与特征':'https://docs.opencv.org/4.10.0/da/d9b/group__features2d.html',
 '匹配与配准':'https://docs.opencv.org/4.10.0/dc/dc3/tutorial_py_matcher.html',
 '标定与三维':'https://docs.opencv.org/4.10.0/d9/d0c/group__calib3d.html',
 '绘图与视频':'https://docs.opencv.org/4.10.0/d6/d6e/group__imgproc__draw.html',
 '其他接口':'https://docs.opencv.org/4.10.0/d6/d00/tutorial_py_root.html',
}
curated = {e['name']: e for e in ENTRIES}
def category_for(name, doc=''):
    lower=name.lower()
    if name in curated: return curated[name]['category']
    if any(x in lower for x in ['calib','stereo','fisheye','undistort','rodrigues','pnp','triangul','projectpoint','essential','fundamental','recoverpose','chessboard','epiline']): return '标定与三维'
    if any(x in lower for x in ['match','homography','flann','stitch']): return '匹配与配准'
    if any(x in lower for x in ['sift','orb','corner','feature','keypoint','akaze','brisk','kaze','mser','fastfeature','agast','brief','detector']): return '角点与特征'
    if any(x in lower for x in ['color','hsv','bgr','rgb','norm','hist','clahe','bitwise','split','merge','absdiff','lut','psnr','minmax','meanstd']): return '颜色与像素'
    if any(x in lower for x in ['thresh','morph','erode','dilate','connectedcomponent','distancetransform','structuring']): return '阈值与形态学'
    if any(x in lower for x in ['blur','filter','sobel','scharr','laplacian','gaussian','border','deriv','canny']): return '滤波与梯度'
    if any(x in lower for x in ['contour','hough','arclength','bounding','boxpoint','minarea','moment','convex','approxpoly','fitellipse','fitline']): return '边缘与轮廓'
    if any(x in lower for x in ['resize','affine','perspective','remap','rotate','rotationmatrix','flip','inter_','warppolar']): return '几何变换'
    if any(x in lower for x in ['imread','imwrite','imencode','imdecode','imshow','waitkey','pollkey','window','trackbar','mousecallback']): return '读写与窗口'
    if any(x in lower for x in ['video','capture','draw','line','rectangle','circle','puttext','ellipse','font_','polylines','fillpoly']): return '绘图与视频'
    return '其他接口'

def clean_doc(doc):
    lines=(doc or '').strip().splitlines()
    return '\n'.join(re.sub(r'^\.\s?', '', line) for line in lines)
def summary(doc):
    for line in doc.splitlines():
        s=re.sub(r'^(@brief\s*|\.\s*)','',line).strip()
        if s and '->' not in s and not s.startswith('@'):
            return s[:400]
    return '本机 OpenCV 提供的接口；请结合调用签名和下方原始说明使用。'
def get_signature(name, doc, kind):
    lines=[line.strip() for line in doc.splitlines() if '->' in line][:5]
    if lines:
        return '\n'.join('cv.'+name+'('+line.split('(',1)[1] if '(' in line else line for line in lines)
    return 'cv.'+name if kind in ['constant','property'] else 'cv.'+name+'(...)'
def add_symbol(name,obj,kind):
    doc=clean_doc(getattr(obj,'__doc__',None)) if kind!='constant' else ''
    category=category_for(name,doc)
    item=dict(name=name, kind=kind, category=category, title='', description=summary(doc),
              signature=get_signature(name,doc,kind), doc=doc, curated=False,
              aliases=[], related=[], params=[], returns='', tips=[], code='')
    if kind=='constant':
        value=obj if isinstance(obj,(int,float,str,bool)) else str(obj)
        item.update(value=value, title='参数常量', description='当前环境中的常量值：'+str(value)+'。通常作为函数参数使用。',
                    code=f'print(cv.{name})', returns='常量值；它不是函数，不要添加调用括号。')
    elif kind=='property':
        item.update(title='对象属性', tips=['这是对象属性，通过实际对象访问；不是普通顶层函数。'])
    elif kind=='method':
        item.update(title='对象方法', tips=['这是对象方法，通常需要先创建相应对象，再用对象调用。'])
    elif kind=='class':
        item.update(title='类 / 对象构造', tips=['构造参数请以本机原始文档和对应官方页面为准。'])
    else: item['title']='函数接口'
    if name in curated:
        item.update(curated[name])
    if name.startswith(('imread','imwrite','imdecode','imencode','haveImage','imcount')):
        item['source']='https://docs.opencv.org/4.10.0/d4/da8/group__imgcodecs.html'
    elif name in ['threshold','adaptiveThreshold','inRange','cvtColor','calcHist','equalizeHist','createCLAHE']:
        item['source']='https://docs.opencv.org/4.10.0/d6/d00/tutorial_py_root.html'
    elif name in ['VideoCapture','VideoCapture.read','VideoCapture.release']:
        item['source']='https://docs.opencv.org/4.10.0/d8/dfe/classcv_1_1VideoCapture.html'
    else: item['source']=DOCS[category]
    return item

items={}
modules=[('',cv2)]
for ns in ['aruco','barcode','detail','dnn','fisheye','flann','gapi','ml','ocl','ogl','segmentation','videoio_registry']:
    module=getattr(cv2,ns,None)
    if isinstance(module,types.ModuleType): modules.append((ns+'.',module))
for prefix,module in modules:
    for key in sorted(dir(module)):
        if key.startswith('_'): continue
        obj=getattr(module,key)
        name=prefix+key
        if inspect.isclass(obj) and (getattr(obj,'__module__','') or '').startswith('cv2'):
            items[name]=add_symbol(name,obj,'class')
            for method_name in sorted(dir(obj)):
                if method_name.startswith('_'): continue
                try: member=getattr(obj,method_name)
                except (AttributeError,TypeError): continue
                if callable(member):
                    method=name+'.'+method_name
                    items[method]=add_symbol(method,member,'method')
                elif inspect.isgetsetdescriptor(member) or inspect.ismemberdescriptor(member):
                    prop=name+'.'+method_name
                    items[prop]=add_symbol(prop,member,'property')
        elif callable(obj) and not inspect.isclass(obj):
            items[name]=add_symbol(name,obj,'function')
        elif isinstance(obj,(int,float,str,bool)) and key.upper()==key:
            items[name]=add_symbol(name,obj,'constant')

missing=sorted(set(curated)-set(items))
if missing: raise RuntimeError('中文词条不属于本机 API：'+repr(missing))
data=sorted(items.values(),key=lambda e:(not e['curated'], CATEGORIES.index(e['category']), e['name'].lower()))
meta=dict(version=cv2.__version__, package=importlib.metadata.version('opencv-python'),
          generated='2026-11-24', total=len(data), curated=len(curated),
          kinds={kind:sum(e['kind']==kind for e in data) for kind in ['function','class','method','constant','property']},
          categories=CATEGORIES)
payload=json.dumps(dict(meta=meta,entries=data,preamble=PREAMBLE),ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
template=(HERE/'template.html').read_text(encoding='utf-8')
html=template.replace('/*__DICTIONARY_DATA__*/',payload)
target=ROOT/'OpenCV函数词典.html'
target.write_text(html,encoding='utf-8')
dist=importlib.metadata.distribution('opencv-python')
license_path=Path(dist.locate_file('opencv_python-'+dist.version+'.dist-info'))/'LICENSE.txt'
if license_path.is_file(): shutil.copyfile(license_path,ROOT/'OpenCV-Python-LICENSE.txt')
third_party=license_path.with_name('LICENSE-3RD-PARTY.txt')
if third_party.is_file(): shutil.copyfile(third_party,ROOT/'OpenCV-Third-Party-LICENSES.txt')
(ROOT/'index-summary.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(meta=meta,path=str(target),size=target.stat().st_size),ensure_ascii=False,indent=2))

"""面向本课程的中文词条；代码与页面都可离线重建。"""
ENTRIES = []
def entry(name, title, category, description, signature, params, returns, code, tips='', aliases='', related='', interactive=False):
    ENTRIES.append(dict(name=name, title=title, category=category, description=description,
        signature=signature, params=[p.split('|',1) for p in params.split(';') if p], returns=returns,
        code=code, tips=tips.split('|') if tips else [], aliases=aliases.split(),
        related=related.split(), interactive=interactive, curated=True))

PREAMBLE = '''import cv2 as cv
import numpy as np
from pathlib import Path
from datetime import datetime

# 自动生成演示图；不依赖外部照片。
img = np.full((360, 540, 3), 235, dtype=np.uint8)
for row in range(8):
    for col in range(8):
        value = 20 if (row + col) % 2 == 0 else 240
        cv.rectangle(img, (20 + col*24, 20 + row*24),
                     (43 + col*24, 43 + row*24), (value,)*3, -1)
cv.circle(img, (380, 130), 65, (0, 100, 240), -1)
cv.rectangle(img, (285, 235), (470, 310), (220, 80, 20), -1)
cv.putText(img, "OpenCV", (25, 295), cv.FONT_HERSHEY_SIMPLEX,
           1.1, (30, 30, 30), 2)
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
Path("results").mkdir(exist_ok=True)

'''

entry('imread','读取图片','读写与窗口','把磁盘中的图片读成 NumPy 数组。彩色图片默认按 B、G、R 三个通道排列。',
 'img = cv.imread(filename, flags=cv.IMREAD_COLOR)', 'filename|图片路径；字符串;flags|读取方式，如彩色、灰度或保留透明通道', '读取成功得到 ndarray，失败通常得到 None。',
 '''# 先生成一张演示文件，再读取它。
cv.imwrite("results/dictionary_demo.png", img)
loaded = cv.imread("results/dictionary_demo.png", cv.IMREAD_COLOR)
if loaded is None:
    raise FileNotFoundError("读取失败，请检查文件路径")
print(loaded.shape)  # (高, 宽, 通道数)''',
 'Windows 中文路径若读取失败，使用 np.fromfile + cv.imdecode。|相对路径从程序的工作目录计算，不一定从脚本所在文件夹计算。', '读图 打开 文件 图片 加载', 'imdecode imshow imwrite IMREAD_GRAYSCALE')
entry('imwrite','保存图片','读写与窗口','把数组编码并保存到指定文件；扩展名决定 PNG、JPEG 等格式。',
 'ok = cv.imwrite(filename, img)', 'filename|输出完整路径；文件夹要先存在;img|待保存的图像数组', '布尔值；True 表示写入成功。',
 '''# 时间戳让重复运行生成不同文件名，避免覆盖旧结果。
path = Path("results") / f"image_{datetime.now():%Y%m%d_%H%M%S_%f}.png"
ok = cv.imwrite(str(path), img)
if not ok:
    raise OSError(f"保存失败：{path}")
print(path)''',
 '保存到同一文件夹、同一文件名时会覆盖已有文件。|PNG 可无损保存；JPEG 通常有损；保存前检查返回值。|中文路径可改用 cv.imencode 后调用 tofile。', '存图 写入 输出 覆盖 保存', 'imencode imread')
entry('imdecode','从内存读取图片','读写与窗口','把编码后的图片字节解码成图像，适合 Windows 中文文件路径。',
 'img = cv.imdecode(buf, flags)', 'buf|包含编码文件内容的 uint8 一维数组;flags|与 imread 相同的读取方式', '图像数组；解码失败返回 None。',
 '''path = Path("results") / "中文图片.png"
ok, encoded = cv.imencode(".png", img)
if not ok:
    raise ValueError("编码失败")
encoded.tofile(str(path))
loaded = cv.imdecode(np.fromfile(str(path), dtype=np.uint8), cv.IMREAD_COLOR)
assert loaded is not None
print(loaded.shape)''',
 '解码的是 PNG/JPEG 等文件字节，不是直接把像素展平后的数组。', '中文路径 中文 乱码 解码 读图', 'imread imencode')
entry('imencode','把图像编码成字节','读写与窗口','把图像压缩编码到内存；与 tofile 配合可保存到中文路径。',
 'ok, buffer = cv.imencode(ext, img)', 'ext|扩展名，必须有点，如 .png;img|图像数组', '成功标志和 uint8 编码字节数组。',
 '''ok, buffer = cv.imencode(".png", img)
if not ok:
    raise ValueError("PNG 编码失败")
path = Path("results") / "中文输出.png"
buffer.tofile(str(path))
print(path)''', aliases='编码 中文路径 保存 字节', related='imdecode imwrite')
entry('imshow','显示图片窗口','读写与窗口','在独立窗口中显示图片；只调用 imshow 不保证窗口能正常停留和响应。',
 'cv.imshow(winname, img)', 'winname|窗口标题；相同标题会更新同一个窗口;img|待显示图像，最常用的是 uint8 数组', '无返回值。',
 '''cv.imshow("Preview", img)
cv.waitKey(0)  # 选中窗口，按任意键继续
cv.destroyAllWindows()''',
 '要配合 waitKey 或 pollKey 处理窗口事件。|uint8 通常按 0~255 显示；浮点图通常按 0~1 显示；显示前注意数值范围。|网页不会执行 Python；把代码复制到 PyCharm 运行。', '显示 弹窗 看图 窗口 图片', 'waitKey namedWindow destroyAllWindows', True)
entry('waitKey','等待按键并处理窗口事件','读写与窗口','让 OpenCV 图像窗口响应事件，并等待用户按键。',
 'key = cv.waitKey(delay)', 'delay|0 表示一直等待；正数表示至少等待约这么多毫秒，实际时间受系统调度影响', '按键编码；在有限等待时间内无按键通常为 -1。',
 '''cv.imshow("Press q to quit", img)
while True:
    if cv.waitKey(30) & 0xFF == ord("q"):
        break
cv.destroyAllWindows()''',
 '按键需要图像窗口处于活动状态。|waitKey(0) 在等待按键时，终端没有新输出通常是正常的。', '按键 等待 卡住 延时 无弹窗', 'imshow destroyAllWindows', True)
entry('destroyAllWindows','关闭所有 OpenCV 窗口','读写与窗口','销毁由 OpenCV HighGUI 创建的所有窗口。',
 'cv.destroyAllWindows()', '', '无返回值。', 'cv.imshow("Preview", img)\ncv.waitKey(0)\ncv.destroyAllWindows()',
 '不会关闭浏览器、PyCharm 或其他应用的窗口。', '关闭 窗口 退出', 'imshow waitKey', True)
entry('namedWindow','创建可调整大小的窗口','读写与窗口','先创建指定属性的图像窗口，再用 imshow 放入图像。',
 'cv.namedWindow(winname, flags=cv.WINDOW_AUTOSIZE)', 'winname|窗口名;flags|WINDOW_NORMAL 允许用户调整窗口尺寸', '无返回值。',
 'cv.namedWindow("Preview", cv.WINDOW_NORMAL)\ncv.resizeWindow("Preview", 720, 480)\ncv.imshow("Preview", img)\ncv.waitKey(0)\ncv.destroyAllWindows()', aliases='窗口 大小 缩放', related='imshow resizeWindow', interactive=True)
entry('resizeWindow','调整显示窗口大小','读写与窗口','调整窗口尺寸；与 resize 修改图像像素尺寸是两个操作。',
 'cv.resizeWindow(winname, width, height)', 'winname|已经创建的可调整大小的窗口;width, height|窗口宽和高', '无返回值。',
 'cv.namedWindow("Preview", cv.WINDOW_NORMAL)\ncv.resizeWindow("Preview", 800, 500)\ncv.imshow("Preview", img)\ncv.waitKey(0)\ncv.destroyAllWindows()',
 '通常先用 WINDOW_NORMAL 创建窗口。', '窗口 宽高 显示', 'namedWindow resize', True)

entry('cvtColor','转换颜色空间','颜色与像素','在 BGR、RGB、灰度、HSV 等颜色表示之间转换。',
 'dst = cv.cvtColor(src, code)', 'src|输入图像;code|转换规则，例如 cv.COLOR_BGR2GRAY', '转换后的新图像数组。',
 'gray_result = cv.cvtColor(img, cv.COLOR_BGR2GRAY)\nhsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)\nrgb = cv.cvtColor(img, cv.COLOR_BGR2RGB)\nprint(gray_result.shape, hsv.shape)',
 'OpenCV 彩色读图通常是 BGR；Matplotlib 展示彩色图通常按 RGB。|灰度图通常是 (高, 宽)，没有第三个通道维度。', '灰度 颜色 颜色空间 RGB BGR HSV 通道 转换', 'COLOR_BGR2GRAY COLOR_BGR2HSV split')
entry('split','拆分图像通道','颜色与像素','将多通道图像拆成独立的单通道数组。', 'channels = cv.split(img)', 'img|多通道图像', '包含各通道数组的元组。',
 'b, g, r = cv.split(img)\nprint(b.shape, g.shape, r.shape)', 'BGR 图像的第一个通道是蓝色，不是红色。|只需一个通道时可直接使用 img[:, :, 0]。', '拆分 通道 蓝绿红', 'merge cvtColor')
entry('merge','合并图像通道','颜色与像素','把多个同样大小和数据类型的单通道数组合并。', 'dst = cv.merge(channels)', 'channels|同尺寸、同数据类型的通道序列', '合并后的多通道图像。',
 'b, g, r = cv.split(img)\nrestored = cv.merge((b, g, r))\nprint(np.array_equal(restored, img))', aliases='合并 通道', related='split')
entry('inRange','按数值范围生成掩膜','颜色与像素','逐像素检查所有通道是否都在上下界内；满足时输出 255，否则输出 0。',
 'mask = cv.inRange(src, lowerb, upperb)', 'src|单通道或多通道数组;lowerb, upperb|各通道的下界和上界，包含边界', '单通道 uint8 掩膜。',
 'hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)\nmask = cv.inRange(hsv, (0, 80, 80), (20, 255, 255))\nselected = cv.bitwise_and(img, img, mask=mask)\nprint(np.count_nonzero(mask))',
 '普通 8 位 HSV 中 H 为 0~179，S、V 为 0~255；红色跨越 H 轴两端，常需两段范围合并。', '颜色提取 掩膜 范围 分割 HSV', 'bitwise_and cvtColor')
entry('bitwise_and','按掩膜保留图像区域','颜色与像素','对数组做逐位与；将同一图像传入两次并指定 mask，可只保留选中的像素。',
 'dst = cv.bitwise_and(src1, src2, mask=mask)', 'src1, src2|对应输入数组;mask|单通道 8 位掩膜；非零处允许写入输出', '运算后的数组。',
 'mask = np.zeros(gray.shape, np.uint8)\ncv.circle(mask, (380, 130), 80, 255, -1)\nselected = cv.bitwise_and(img, img, mask=mask)\nprint(selected.shape)',
 '逐位与不是算术乘法；浮点数组的逐位操作涉及底层二进制表示。', '掩膜 mask 抠图 选区 与', 'inRange bitwise_or')
entry('addWeighted','按权重混合两张图','颜色与像素','计算 dst = alpha×src1 + beta×src2 + gamma，可用于叠加、透明混合和锐化。',
 'dst = cv.addWeighted(src1, alpha, src2, beta, gamma)', 'src1, src2|尺寸和兼容类型相同的图像;alpha, beta|两张图的权重;gamma|额外加上的亮度偏置', '混合后的图像；整数输出会按类型范围饱和。',
 'blurred = cv.GaussianBlur(img, (9, 9), 2)\nsharpened = cv.addWeighted(img, 1.5, blurred, -0.5, 0)\nprint(sharpened.shape)',
 '透明叠加常取 alpha+beta=1；锐化可以使用负权重。', '混合 叠加 权重 透明 锐化', 'add GaussianBlur')
entry('add','像素相加并饱和截断','颜色与像素','将对应元素相加；uint8 输出超出 255 的数值会截到 255。',
 'dst = cv.add(src1, src2)', 'src1, src2|兼容尺寸和类型的输入', '相加后的数组。',
 'a = np.array([[250]], np.uint8)\nb = np.array([[20]], np.uint8)\nprint(cv.add(a, b))  # [[255]]\nprint(a + b)         # uint8 NumPy 加法会回绕', '不要把 uint8 的 NumPy 加法回绕行为当成 OpenCV 饱和加法。', '加法 溢出 饱和 像素', 'subtract addWeighted')
entry('absdiff','绝对差分','颜色与像素','计算对应元素之差的绝对值，常用于比较图像或检测变化。', 'dst = cv.absdiff(src1, src2)', 'src1, src2|兼容尺寸和类型的输入', '差异大小数组。',
 'shifted = cv.warpAffine(img, np.float32([[1, 0, 8], [0, 1, 0]]), (540, 360))\ndifference = cv.absdiff(img, shifted)\nprint(float(difference.mean()))', '两张图应先对齐，否则位移本身也会产生大量差异。', '差分 差异 变化 相减', 'PSNR')
entry('normalize','归一化数值范围','颜色与像素','按指定范数或最小最大值规则缩放数组。',
 'dst = cv.normalize(src, None, alpha, beta, norm_type)', 'src|输入数组;alpha, beta|MINMAX 模式下是目标下界和上界;norm_type|cv.NORM_MINMAX 表示范围映射', '归一化后的数组。',
 'values = np.float32([[10, 20], [30, 50]])\nscaled = cv.normalize(values, None, 0, 255, cv.NORM_MINMAX)\npreview = scaled.astype(np.uint8)\nprint(scaled)',
 '归一化会改变绝对幅值，适合显示但不一定适合定量比较。', '归一化 拉伸 范围 显示', 'convertScaleAbs')
entry('convertScaleAbs','缩放、取绝对值并转成 8 位','颜色与像素','依次计算 alpha×src+beta、取绝对值，并转换为饱和 uint8。',
 'dst = cv.convertScaleAbs(src, alpha=1, beta=0)', 'src|常见输入是有正负值的梯度;alpha, beta|缩放系数和偏置', 'uint8 数组。',
 'gx = cv.Sobel(gray, cv.CV_64F, 1, 0, ksize=3)\nvisible = cv.convertScaleAbs(gx)\nprint(visible.dtype)',
 '绝对值会丢失梯度方向；计算阶段应保留原来的有符号数据。', '绝对值 梯度 显示 八位', 'Sobel Laplacian')
entry('calcHist','计算灰度或颜色直方图','颜色与像素','统计某个通道的像素落入各个数值区间的次数。',
 'hist = cv.calcHist(images, channels, mask, histSize, ranges)', 'images|图像列表，如 [gray];channels|待统计的通道下标，如 [0];mask|None 表示整幅图;histSize|各维区间个数，如 [256];ranges|范围，如 [0, 256]，右边界不包含', '浮点直方图数组。',
 'hist = cv.calcHist([gray], [0], None, [256], [0, 256])\nprint(hist.shape, hist.sum(), gray.size)', aliases='直方图 统计 分布 灰度', related='equalizeHist createCLAHE')
entry('equalizeHist','灰度直方图均衡化','颜色与像素','重新分配灰度值以调整整体对比度。', 'dst = cv.equalizeHist(src)', 'src|8 位单通道图像', '均衡化后的灰度图。',
 'enhanced = cv.equalizeHist(gray)\nprint(enhanced.shape)', '不能直接把普通三通道 BGR 图传给它；彩色图通常处理亮度通道。', '均衡化 直方图 对比度 增强', 'calcHist createCLAHE')
entry('createCLAHE','创建局部对比度增强器','颜色与像素','创建限制对比度的局部直方图均衡对象，再调用 apply。',
 'clahe = cv.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))', 'clipLimit|限制局部直方图峰值的阈值参数;tileGridSize|横向和纵向分块数量，不是每块的像素尺寸', 'CLAHE 对象。',
 'clahe = cv.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))\nenhanced = clahe.apply(gray)\nprint(enhanced.shape)', aliases='局部对比度 增强 均衡化', related='equalizeHist CLAHE.apply')

entry('blur','均值滤波','滤波与梯度','把邻域内像素的平均值作为输出，能平滑噪声，也会模糊边缘。',
 'dst = cv.blur(src, ksize)', 'src|输入图像;ksize|核的 (宽, 高)，如 (5, 5)', '尺寸通常与输入相同的平滑图像。', 'smoothed = cv.blur(img, (5, 5))\nprint(smoothed.shape)', aliases='均值 平均 平滑 模糊', related='GaussianBlur medianBlur')
entry('GaussianBlur','高斯滤波','滤波与梯度','用离中心越远权重越小的邻域加权平均平滑图像，常用于边缘检测前降噪。',
 'dst = cv.GaussianBlur(src, ksize, sigmaX)', 'src|输入图像;ksize|通常取正奇数核尺寸，如 (5, 5)；可用 (0, 0) 配合 sigma 自动确定;sigmaX|横向标准差；0 表示按核尺寸估计', '高斯平滑后的图像。',
 'smoothed = cv.GaussianBlur(img, (5, 5), 1.2)\nedges = cv.Canny(cv.cvtColor(smoothed, cv.COLOR_BGR2GRAY), 60, 150)\nprint(edges.shape)',
 '核越大或 sigma 越大通常越模糊，但也会损失细节。', '高斯 模糊 降噪 平滑 滤波', 'blur medianBlur Canny')
entry('medianBlur','中值滤波','滤波与梯度','用邻域像素的中位数代替中心像素，对椒盐噪声常有用。', 'dst = cv.medianBlur(src, ksize)', 'src|输入图像；支持的类型随核大小有所限制;ksize|大于 1 的奇数，如 3 或 5', '滤波后的图像。',
 'noisy = img.copy()\nrng = np.random.default_rng(0)\nnoisy[rng.random(gray.shape) < 0.02] = 0\nfiltered = cv.medianBlur(noisy, 5)\nprint(filtered.shape)', aliases='中值 椒盐 降噪', related='GaussianBlur bilateralFilter')
entry('bilateralFilter','双边滤波','滤波与梯度','同时考虑像素位置距离和颜色差异，在平滑时尽量保留边缘。',
 'dst = cv.bilateralFilter(src, d, sigmaColor, sigmaSpace)', 'src|通常为 8 位或 float32 的 1/3 通道图;d|邻域直径；非正值时按 sigmaSpace 估计;sigmaColor|颜色差异的平滑尺度;sigmaSpace|空间距离的平滑尺度', '滤波后的新图像。',
 'filtered = cv.bilateralFilter(img, 9, 75, 75)\nprint(filtered.shape)', '通常比高斯滤波慢；该函数不支持输入输出原地重用。', '双边 保边 平滑 降噪', 'GaussianBlur')
entry('filter2D','自定义滤波核','滤波与梯度','用指定核对图像进行相关运算，可实现均值、锐化等线性滤波。',
 'dst = cv.filter2D(src, ddepth, kernel)', 'src|输入图像;ddepth|-1 表示沿用输入深度；求有符号响应可用 cv.CV_32F;kernel|二维浮点核', '核响应图。',
 'kernel = np.float32([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])\nsharpened = cv.filter2D(img, -1, kernel)\nprint(sharpened.shape)',
 'filter2D 默认做相关运算，不会先翻转核；对称核时与卷积相同。|uint8 输出会把负值和超过 255 的数值截断。', '卷积 核 相关 锐化 Prewitt 自定义', 'Sobel GaussianBlur')
entry('Sobel','计算一阶或混合偏导','滤波与梯度','用 Sobel 核估计图像沿 x 或 y 方向的亮度变化。',
 'dst = cv.Sobel(src, ddepth, dx, dy, ksize=3)', 'src|常用灰度图;ddepth|用 CV_32F 或 CV_64F 保留负响应;dx, dy|x、y 求导阶数；(1,0) 求横向导数;ksize|常用 3、5、7', '带方向和正负号的梯度响应图。',
 'gx = cv.Sobel(gray, cv.CV_64F, 1, 0, ksize=3)\ngy = cv.Sobel(gray, cv.CV_64F, 0, 1, ksize=3)\nmagnitude = cv.magnitude(gx, gy)\nprint(magnitude.shape)',
 'x 方向梯度大常对应竖直边缘，别把求导方向和边缘走向混淆。|直接使用 uint8 输出会丢失负梯度。', '梯度 导数 边缘 横向 纵向', 'Scharr Laplacian convertScaleAbs')
entry('Scharr','3×3 高精度梯度','滤波与梯度','用 Scharr 算子计算一阶导数，在 3×3 核条件下改善梯度方向精度。',
 'dst = cv.Scharr(src, ddepth, dx, dy)', 'ddepth|CV_32F 或 CV_64F;dx, dy|只能是一阶 x 或 y 导数的组合', '梯度响应图。',
 'gx = cv.Scharr(gray, cv.CV_32F, 1, 0)\nprint(gx.shape)', aliases='梯度 导数 Scharr', related='Sobel')
entry('Laplacian','拉普拉斯二阶导数','滤波与梯度','估计横向和纵向二阶导数之和，突出亮度变化剧烈的位置。',
 'dst = cv.Laplacian(src, ddepth, ksize=1)', 'src|通常先降噪的灰度图;ddepth|使用浮点深度保留正负响应;ksize|正奇数核尺寸', '拉普拉斯响应图。',
 'smoothed = cv.GaussianBlur(gray, (5, 5), 1)\nresponse = cv.Laplacian(smoothed, cv.CV_64F, ksize=3)\npreview = cv.convertScaleAbs(response)\nprint(response.min(), response.max())',
 '对噪声敏感；LoG 可理解为先高斯平滑，再做拉普拉斯。', '拉普拉斯 二阶 LoG 边缘', 'GaussianBlur Sobel')

entry('threshold','固定阈值分割','阈值与形态学','用同一个阈值处理所有像素；二值化时把图像分成两类。',
 'used_threshold, dst = cv.threshold(src, thresh, maxval, type)', 'src|入门常用 8 位灰度图;thresh|固定阈值；Otsu 模式下会自动估计;maxval|二值化的前景值，常为 255;type|如 THRESH_BINARY 或 THRESH_BINARY + THRESH_OTSU', '实际阈值和处理后的图像两个返回值。',
 'used, binary = cv.threshold(gray, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU)\nprint("自动选择的阈值：", used)',
 '它返回两个值，不能只把整个返回元组当图片。|普通阈值可支持多通道；Otsu、Triangle 有额外类型和通道限制。', '阈值 二值化 分割 Otsu 大津', 'adaptiveThreshold THRESH_BINARY THRESH_OTSU')
entry('adaptiveThreshold','自适应局部阈值','阈值与形态学','为每个像素按邻域估计阈值，适合光照不均的文档等图像。',
 'dst = cv.adaptiveThreshold(src, maxValue, adaptiveMethod, thresholdType, blockSize, C)', 'src|8 位单通道图;maxValue|常为 255;adaptiveMethod|局部均值或高斯加权均值;blockSize|大于 1 的奇数邻域尺寸;C|从局部统计值中减去的常数', '二值图。',
 'binary = cv.adaptiveThreshold(gray, 255, cv.ADAPTIVE_THRESH_GAUSSIAN_C,\n                              cv.THRESH_BINARY, 11, 2)\nprint(binary.shape)', aliases='局部 自适应 光照不均 阈值', related='threshold')
entry('getStructuringElement','创建形态学结构元素','阈值与形态学','生成矩形、椭圆或十字形的形态学核。',
 'kernel = cv.getStructuringElement(shape, ksize)', 'shape|MORPH_RECT / MORPH_ELLIPSE / MORPH_CROSS;ksize|核的 (宽, 高)', 'uint8 核数组。',
 'kernel = cv.getStructuringElement(cv.MORPH_ELLIPSE, (5, 5))\nprint(kernel)', aliases='核 结构元素 矩形 椭圆', related='erode dilate morphologyEx')
entry('erode','腐蚀前景','阈值与形态学','对邻域取局部最小值；对白色前景会使其边界向内收缩。',
 'dst = cv.erode(src, kernel, iterations=1)', 'src|二值或灰度图;kernel|结构元素;iterations|重复次数', '腐蚀后的图。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\nresult = cv.erode(binary, np.ones((3, 3), np.uint8), iterations=1)\nprint(np.count_nonzero(binary), np.count_nonzero(result))',
 '形态学中的前景通常按白色理解；前景反色后视觉含义也会改变。', '腐蚀 收缩 去小点', 'dilate morphologyEx')
entry('dilate','膨胀前景','阈值与形态学','对邻域取局部最大值；对白色前景会使其边界向外扩张。',
 'dst = cv.dilate(src, kernel, iterations=1)', 'src|二值或灰度图;kernel|结构元素;iterations|重复次数', '膨胀后的图。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\nresult = cv.dilate(binary, np.ones((3, 3), np.uint8))\nprint(np.count_nonzero(binary), np.count_nonzero(result))', aliases='膨胀 扩张 连接', related='erode morphologyEx')
entry('morphologyEx','开闭运算等复合形态学','阈值与形态学','用一个接口执行开运算、闭运算、形态学梯度、顶帽或黑帽。',
 'dst = cv.morphologyEx(src, op, kernel)', 'src|输入图;op|MORPH_OPEN 开运算；MORPH_CLOSE 闭运算;kernel|结构元素', '形态学处理后的图。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\nkernel = cv.getStructuringElement(cv.MORPH_RECT, (3, 3))\nopened = cv.morphologyEx(binary, cv.MORPH_OPEN, kernel)\nclosed = cv.morphologyEx(binary, cv.MORPH_CLOSE, kernel)\nprint(opened.shape, closed.shape)',
 '开运算先腐蚀再膨胀，常去除小白点；闭运算先膨胀再腐蚀，常填小黑洞。', '开运算 闭运算 形态学 顶帽 黑帽', 'erode dilate getStructuringElement')
entry('connectedComponentsWithStats','连通区域与面积统计','阈值与形态学','给二值前景的连通区域编号，同时返回包围盒、面积和质心。',
 'count, labels, stats, centers = cv.connectedComponentsWithStats(binary)', 'binary|8 位单通道图，非零为前景;connectivity|4 连通或 8 连通', '数量（含背景）、标签图、统计矩阵和质心坐标。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\ncount, labels, stats, centers = cv.connectedComponentsWithStats(binary, connectivity=8)\nfor i in range(1, count):  # 跳过背景标签 0\n    print(i, "面积", stats[i, cv.CC_STAT_AREA], "质心", centers[i])',
 '标签 0 是背景；count 包含背景，所以前景连通区域数通常为 count-1。', '连通域 面积 质心 区域 分割', 'findContours moments')

entry('resize','修改图像像素尺寸','几何变换','按目标尺寸或比例重新采样图像。', 'dst = cv.resize(src, dsize, fx=0, fy=0, interpolation=cv.INTER_LINEAR)',
 'src|输入图;dsize|目标 (宽, 高)；(0,0) 时用 fx、fy;fx, fy|横纵缩放比例;interpolation|插值规则', '像素尺寸改变后的图像。',
 'small = cv.resize(img, (0, 0), fx=0.5, fy=0.5, interpolation=cv.INTER_AREA)\nprint(img.shape, small.shape)',
 'dsize 是 (宽, 高)，而数组 shape 前两项是 (高, 宽)。|缩小常用 INTER_AREA；保持横纵同比例才不会把图像拉变形。', '缩放 调整大小 尺寸 放大 缩小', 'INTER_AREA INTER_LINEAR resizeWindow')
entry('rotate','按直角旋转','几何变换','把图像旋转 90、180 或 270 度，无需自己构造矩阵。',
 'dst = cv.rotate(src, rotateCode)', 'rotateCode|如 ROTATE_90_CLOCKWISE、ROTATE_180', '旋转后的图。', 'turned = cv.rotate(img, cv.ROTATE_90_CLOCKWISE)\nprint(turned.shape)', aliases='旋转 顺时针 直角', related='getRotationMatrix2D warpAffine')
entry('flip','镜像翻转','几何变换','将图像上下、左右或同时翻转。', 'dst = cv.flip(src, flipCode)', 'flipCode|0 上下翻转；正数左右翻转；负数同时翻转', '镜像后的图。',
 'horizontal = cv.flip(img, 1)\nvertical = cv.flip(img, 0)\nprint(horizontal.shape, vertical.shape)', aliases='镜像 翻转 左右 上下', related='rotate')
entry('getRotationMatrix2D','生成二维旋转矩阵','几何变换','按旋转中心、角度和缩放比例生成 2×3 仿射矩阵。',
 'M = cv.getRotationMatrix2D(center, angle, scale)', 'center|旋转中心 (x, y);angle|角度单位为度；标准图像坐标下正角度表现为逆时针;scale|统一缩放比例', '2×3 矩阵；还需 warpAffine 应用于图像。',
 'h, w = img.shape[:2]\nM = cv.getRotationMatrix2D((w/2, h/2), 30, 1.0)\nrotated = cv.warpAffine(img, M, (w, h))\nprint(M)',
 '画布仍为原大小时，旋转后的角落可能被裁掉。', '旋转 矩阵 角度 仿射', 'warpAffine')
entry('warpAffine','仿射变换图像','几何变换','使用 2×3 矩阵实现平移、旋转、缩放和剪切。', 'dst = cv.warpAffine(src, M, dsize)',
 'src|输入图;M|2×3 仿射矩阵;dsize|输出 (宽, 高)', '变换后的图。', 'M = np.float32([[1, 0, 30], [0, 1, 20]])\nmoved = cv.warpAffine(img, M, (540, 360))\nprint(moved.shape)',
 '默认按前向矩阵解释，再在内部逆映射采样；WARP_INVERSE_MAP 会改变矩阵含义。', '仿射 平移 旋转 矩阵', 'getRotationMatrix2D getAffineTransform warpPerspective')
entry('getAffineTransform','由三对点求仿射矩阵','几何变换','根据三个不共线源点及其目标点，求 2×3 仿射变换。',
 'M = cv.getAffineTransform(src, dst)', 'src, dst|各为 float32 的 (3,2) 坐标数组；点一一对应', '2×3 仿射矩阵。',
 'src = np.float32([[0, 0], [100, 0], [0, 100]])\ndst = np.float32([[20, 10], [120, 10], [20, 110]])\nM = cv.getAffineTransform(src, dst)\nprint(M)', aliases='仿射 三点 矩阵', related='warpAffine')
entry('getPerspectiveTransform','由四对点求透视矩阵','几何变换','根据四对对应点求 3×3 透视变换矩阵，常用于把平面四边形拉正。',
 'H = cv.getPerspectiveTransform(src, dst)', 'src, dst|通常为 float32 的 (4,2) 对应点坐标；避免退化配置', '3×3 单应矩阵。',
 'src = np.float32([[20, 20], [210, 30], [210, 210], [20, 210]])\ndst = np.float32([[0, 0], [199, 0], [199, 199], [0, 199]])\nH = cv.getPerspectiveTransform(src, dst)\nfront = cv.warpPerspective(img, H, (200, 200))\nprint(H)',
 '点的顺序必须一一对应；把角点顺序弄错会导致交叉扭曲。', '透视 矫正 四点 拉正 单应', 'warpPerspective findHomography')
entry('warpPerspective','透视变换图像','几何变换','将 3×3 单应矩阵应用于整张图像。', 'dst = cv.warpPerspective(src, H, dsize)',
 'src|输入图;H|3×3 单应矩阵;dsize|输出 (宽, 高)', '透视变换后的图。',
 'H = np.float64([[1, 0.15, 0], [0, 1, 0], [0.0003, 0, 1]])\nwarped = cv.warpPerspective(img, H, (540, 360))\nprint(warped.shape)',
 '单应变换适用于同一平面等条件，不代表任意三维场景都能这样精确对齐。', '透视 配准 单应 矩阵', 'getPerspectiveTransform perspectiveTransform findHomography')
entry('perspectiveTransform','变换点坐标','几何变换','将透视矩阵应用于一组点；它处理坐标，不处理整张图片。',
 'dst = cv.perspectiveTransform(points, H)', 'points|常用 float32/float64 的 (N,1,2) 点数组;H|相应维度的透视矩阵', '变换后的点数组。',
 'points = np.float32([[10, 20], [50, 80]]).reshape(-1, 1, 2)\nH = np.float64([[1, 0, 30], [0, 1, 20], [0, 0, 1]])\ntransformed = cv.perspectiveTransform(points, H)\nprint(transformed.reshape(-1, 2))', aliases='坐标 点 单应 映射', related='warpPerspective findHomography')

entry('Canny','提取细边缘','边缘与轮廓','结合梯度、非极大值抑制和双阈值连接，提取较细的亮度边界。',
 'edges = cv.Canny(image, threshold1, threshold2)', 'image|入门使用 8 位灰度图;threshold1|低阈值;threshold2|高阈值；两者约束的是梯度强度', 'uint8 单通道边缘图，边缘通常为 255。',
 'smooth = cv.GaussianBlur(gray, (5, 5), 1.2)\nedges = cv.Canny(smooth, 60, 150)\ncv.imwrite("results/edges.png", edges)\nprint("边缘像素：", np.count_nonzero(edges))',
 'Canny 的两个阈值不是直接给原始灰度分档。|阈值越高通常检测越少；常先适量降噪，但不要模糊掉细节。', '边缘 轮廓 检测 双阈值', 'GaussianBlur Sobel findContours')
entry('findContours','寻找轮廓点集','边缘与轮廓','从二值前景中提取边界，并给出轮廓间的层级关系。',
 'contours, hierarchy = cv.findContours(binary, mode, method)', 'binary|入门用 8 位单通道二值图，非零为前景;mode|RETR_EXTERNAL 只取最外层；RETR_TREE 取层级;method|CHAIN_APPROX_SIMPLE 压缩直线段上的冗余点', '轮廓列表和层级信息；OpenCV 4.x 通常是两个返回值。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\ncontours, hierarchy = cv.findContours(binary, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)\nprint("轮廓数：", len(contours))',
 '轮廓是点序列，不是已经画好的图片。', '轮廓 边界 点集 层级', 'drawContours contourArea RETR_EXTERNAL')
entry('drawContours','绘制轮廓','边缘与轮廓','把轮廓画到指定图像上。', 'canvas = cv.drawContours(image, contours, contourIdx, color, thickness=1)',
 'image|目标画布；通常会被直接修改;contours|轮廓列表;contourIdx|-1 表示所有轮廓;color|BGR 颜色;thickness|-1 表示填充', '绘制后的图像，也修改传入的画布。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\ncontours, _ = cv.findContours(binary, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)\ncanvas = img.copy()\ncv.drawContours(canvas, contours, -1, (0, 255, 0), 2)\nprint(canvas.shape)', aliases='画轮廓 绘制 边界', related='findContours')
entry('contourArea','计算轮廓包围面积','边缘与轮廓','根据轮廓多边形的坐标计算面积。', 'area = cv.contourArea(contour, oriented=False)',
 'contour|轮廓点数组;oriented|True 时返回带方向符号的面积', '面积浮点值，像素坐标下单位为像素的平方。',
 'contour = np.int32([[[0, 0]], [[40, 0]], [[40, 30]], [[0, 30]]])\nprint(cv.contourArea(contour))  # 1200.0',
 '它是多边形几何面积，与数掩膜中的白色像素不完全相同。', '面积 轮廓 多边形', 'arcLength moments')
entry('arcLength','计算曲线周长','边缘与轮廓','把相邻点之间的线段长度相加。', 'length = cv.arcLength(curve, closed)',
 'curve|点序列;closed|True 时补上末点到起点的线段', '曲线长度。',
 'contour = np.float32([[[0, 0]], [[40, 0]], [[40, 30]], [[0, 30]]])\nprint(cv.arcLength(contour, True))  # 140.0', aliases='周长 长度 曲线', related='approxPolyDP contourArea')
entry('approxPolyDP','用较少的点逼近轮廓','边缘与轮廓','以给定最大偏差容限对折线进行简化，常用于形状判断。',
 'approx = cv.approxPolyDP(curve, epsilon, closed)', 'curve|输入曲线;epsilon|允许的近似偏差，常取周长的某个比例;closed|是否闭合', '简化后的顶点。',
 'curve = np.int32([[[0, 0]], [[20, 1]], [[40, 0]], [[40, 30]], [[0, 30]]])\nepsilon = 0.02 * cv.arcLength(curve, True)\nvertices = cv.approxPolyDP(curve, epsilon, True)\nprint(vertices.reshape(-1, 2))', aliases='多边形 逼近 简化 顶点', related='arcLength')
entry('boundingRect','轴对齐包围矩形','边缘与轮廓','求完全包住点集或非零像素的水平矩形。', 'x, y, w, h = cv.boundingRect(points)',
 'points|轮廓点或单通道图像', '左上角坐标、宽、高。',
 'points = np.int32([[10, 20], [60, 80], [90, 30]])\nx, y, w, h = cv.boundingRect(points)\nprint(x, y, w, h)', '返回的是宽高，不是右下角坐标。', '包围盒 矩形 宽高 bbox', 'minAreaRect rectangle')
entry('minAreaRect','最小面积旋转矩形','边缘与轮廓','寻找包住二维点集、面积最小的旋转矩形。', 'rect = cv.minAreaRect(points)',
 'points|float32 或 int32 点数组', '((中心 x, 中心 y), (宽, 高), 角度)。',
 'points = np.float32([[20, 20], [120, 50], [105, 100], [5, 70]])\nrect = cv.minAreaRect(points)\nvertices = cv.boxPoints(rect)\nprint(rect, vertices)', '返回的角度与宽高定义有关，不宜直接当作任意物体唯一的朝向。', '旋转矩形 最小面积 倾角', 'boxPoints boundingRect')
entry('boxPoints','旋转矩形的四个顶点','边缘与轮廓','将 minAreaRect 等得到的旋转矩形转成四个顶点坐标。', 'points = cv.boxPoints(rect)',
 'rect|中心、宽高、角度组成的旋转矩形', '形状 (4,2) 的浮点数组。',
 'rect = ((200.0, 150.0), (120.0, 60.0), 25.0)\npoints = cv.boxPoints(rect)\ncanvas = img.copy()\ncv.polylines(canvas, [np.round(points).astype(np.int32)], True, (0, 255, 0), 2)\nprint(points)', aliases='顶点 四角 旋转矩形', related='minAreaRect polylines')
entry('moments','图像矩与质心','边缘与轮廓','计算轮廓或图像的空间矩；可用一阶矩除以零阶矩求质心。',
 'M = cv.moments(array, binaryImage=False)', 'array|轮廓或单通道图;binaryImage|对图像为 True 时，非零像素都按 1 计算', '含 m00、m10、m01 等键的字典。',
 '_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\nM = cv.moments(binary, binaryImage=True)\nif M["m00"] != 0:\n    cx = M["m10"] / M["m00"]\n    cy = M["m01"] / M["m00"]\n    print("质心：", cx, cy)', '除以 m00 前必须检查它不为 0。', '矩 质心 重心 中心', 'contourArea connectedComponentsWithStats')
entry('HoughLinesP','概率霍夫直线检测','边缘与轮廓','从二值边缘图中检测线段，直接返回各线段的两个端点。',
 'lines = cv.HoughLinesP(edges, rho, theta, threshold, minLineLength=0, maxLineGap=0)',
 'edges|8 位单通道边缘图;rho|距离分辨率，常取 1 像素;theta|角度分辨率，弧度;threshold|累积票数阈值;minLineLength|最短线段;maxLineGap|允许连接的最大间隙', '线段数组，未检出时可能为 None。',
 'edges = cv.Canny(gray, 60, 150)\nlines = cv.HoughLinesP(edges, 1, np.pi/180, 50, minLineLength=40, maxLineGap=8)\nprint("线段数：", 0 if lines is None else len(lines))', aliases='直线 线段 霍夫 Hough', related='Canny HoughCircles')
entry('HoughCircles','霍夫圆检测','边缘与轮廓','利用梯度等信息在灰度图中检测圆。',
 'circles = cv.HoughCircles(gray, cv.HOUGH_GRADIENT, dp, minDist, ...)',
 'gray|8 位单通道图，常先适量平滑;dp|累加器分辨率与图像分辨率的反比;minDist|圆心之间最小间距;param1|内部 Canny 的高阈值参数;param2|HOUGH_GRADIENT 模式中的圆心累加阈值', '圆的中心和半径数组；未检出可能为 None。',
 'smooth = cv.GaussianBlur(gray, (7, 7), 1.5)\ncircles = cv.HoughCircles(smooth, cv.HOUGH_GRADIENT, 1.2, 40,\n                          param1=100, param2=30, minRadius=30, maxRadius=90)\nprint(circles)', '参数含义会随 method 改变，不能将不同方法的参数机械照搬。', '圆 圆心 半径 霍夫', 'Canny')

entry('cornerHarris','Harris 角点响应','角点与特征','根据局部梯度变化计算角点响应，横纵两个方向变化都大时更可能是角点。',
 'response = cv.cornerHarris(src, blockSize, ksize, k)', 'src|单通道 uint8 或 float32 灰度图;blockSize|统计邻域尺寸;ksize|Sobel 孔径;k|Harris 经验参数，常用 0.04~0.06', '与输入同尺寸的 float32 响应图，不是坐标列表。',
 'response = cv.cornerHarris(np.float32(gray), 2, 3, 0.04)\ncanvas = img.copy()\ncanvas[response > 0.01 * response.max()] = (0, 0, 255)\nprint(float(response.max()))',
 '响应阈值只筛候选像素；精确角点坐标还需局部极值筛选等处理。', '角点 Harris 响应 棋盘', 'goodFeaturesToTrack cornerSubPix')
entry('goodFeaturesToTrack','Shi-Tomasi 角点坐标','角点与特征','寻找质量较好且彼此保持一定距离的角点，常用于跟踪。',
 'corners = cv.goodFeaturesToTrack(gray, maxCorners, qualityLevel, minDistance)', 'gray|单通道图;maxCorners|最大角点数，非正值表示不按数量限制;qualityLevel|相对于最大质量的筛选比例;minDistance|角点间最小距离', '常为 (N,1,2) 坐标数组，无角点时可能为 None。',
 'corners = cv.goodFeaturesToTrack(gray, 100, 0.01, 10)\nif corners is not None:\n    print(corners.reshape(-1, 2)[:5])', aliases='角点 ShiTomasi 跟踪 坐标', related='cornerHarris cornerSubPix')
entry('cornerSubPix','亚像素细化角点','角点与特征','从已有初始角点出发，迭代细化坐标到小数精度。',
 'refined = cv.cornerSubPix(gray, corners, winSize, zeroZone, criteria)', 'gray|单通道图;corners|float32 初始角点；会被更新;winSize|搜索半窗口大小；(5,5) 对应约 11×11 区域;zeroZone|(-1,-1) 表示无死区;criteria|最大迭代次数与精度条件', '细化后的角点数组。',
 'corners = cv.goodFeaturesToTrack(gray, 50, 0.01, 10)\nif corners is not None:\n    criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)\n    refined = cv.cornerSubPix(gray, corners, (5, 5), (-1, -1), criteria)\n    print(refined[:3])', aliases='亚像素 精细 角点 标定', related='findChessboardCorners goodFeaturesToTrack')
entry('SIFT_create','创建 SIFT 特征提取器','角点与特征','创建检测尺度和旋转变化下局部特征的对象；再通过对象检测关键点和描述子。',
 'sift = cv.SIFT_create(nfeatures=0)', 'nfeatures|保留的最佳特征数量；0 表示不按此数量限制', 'SIFT 对象；创建本身并没有处理图片。',
 'sift = cv.SIFT_create(nfeatures=500)\nkeypoints, descriptors = sift.detectAndCompute(gray, None)\nprint(len(keypoints), None if descriptors is None else descriptors.shape)',
 '本机 OpenCV 已提供 cv.SIFT_create，无需为 SIFT 再叠装另一个 cv2 包。|SIFT 常用描述子为浮点数组；匹配通常用 NORM_L2。', 'SIFT 尺度不变 特征 关键点 描述子', 'SIFT.detectAndCompute ORB_create BFMatcher drawKeypoints')
entry('ORB_create','创建 ORB 特征提取器','角点与特征','创建较轻量的关键点与二进制描述子提取器。', 'orb = cv.ORB_create(nfeatures=500)',
 'nfeatures|最多保留的特征数量;WTA_K|通常保持默认 2；取 3 或 4 时匹配距离规则要相应改变', 'ORB 对象。',
 'orb = cv.ORB_create(nfeatures=500)\nkeypoints, descriptors = orb.detectAndCompute(gray, None)\nprint(len(keypoints), None if descriptors is None else descriptors.dtype)',
 '默认 ORB 的二进制描述子通常用 NORM_HAMMING；WTA_K=3/4 时使用 NORM_HAMMING2。', 'ORB 特征 关键点 二进制 快速', 'ORB.detectAndCompute SIFT_create BFMatcher')
for cls, creator in [('SIFT','SIFT_create'), ('ORB','ORB_create')]:
    entry(cls+'.detectAndCompute','检测关键点并计算描述子','角点与特征',
      '这是特征提取对象的方法；关键点记录位置、尺度等信息，描述子用于比较两个局部区域。',
      'keypoints, descriptors = detector.detectAndCompute(image, mask)',
      'image|常用灰度图;mask|None 表示全图；也可用单通道掩膜指定检测区域',
      'KeyPoint 序列和描述子矩阵；没有特征时 descriptors 可能为 None。',
      f'detector = cv.{creator}()\nkeypoints, descriptors = detector.detectAndCompute(gray, None)\nif descriptors is not None:\n    print(keypoints[0].pt, descriptors.shape)',
      '需要先创建对象，再用对象调用；不能直接把普通图像传给未绑定的类方法。',
      'detectAndCompute 描述子 特征点 关键点 检测 '+cls, creator+' drawKeypoints BFMatcher')
entry('drawKeypoints','绘制关键点','角点与特征','把关键点画到图像上；丰富模式还能显示尺度和方向。',
 'canvas = cv.drawKeypoints(image, keypoints, None, flags=...)', 'image|输入图;keypoints|检测器给出的 KeyPoint 列表;flags|DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS 显示大小和方向', '带关键点标记的新图。',
 'points = cv.SIFT_create().detect(gray, None)\ncanvas = cv.drawKeypoints(img, points, None,\n    flags=cv.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)\nprint(canvas.shape)', aliases='画点 关键点 尺度 方向 显示', related='SIFT_create ORB_create')
entry('BFMatcher','创建暴力匹配器','匹配与配准','直接比较描述子距离，为特征寻找对应关系。',
 'matcher = cv.BFMatcher(normType, crossCheck=False)', 'normType|SIFT 常用 NORM_L2；默认 ORB 常用 NORM_HAMMING;crossCheck|True 表示最佳匹配需相互一致', '匹配器对象；常用 match 或 knnMatch。',
 'points, des = cv.SIFT_create().detectAndCompute(gray, None)\nif des is not None:\n    matcher = cv.BFMatcher(cv.NORM_L2, crossCheck=True)\n    matches = matcher.match(des, des)  # 自匹配演示\n    print(len(matches))',
 'knnMatch 的比率检验通常搭配 crossCheck=False；别不加区分地叠加两种模式。|自匹配只是接口演示，真实配准应比较两张不同图像。', '暴力 匹配 距离 描述子', 'BFMatcher.knnMatch NORM_L2 NORM_HAMMING drawMatches')
entry('BFMatcher.knnMatch','为每个描述子找最近的 k 个','匹配与配准','为查询描述子返回最近的 k 个候选；k=2 常用于最近与次近距离的比率检验。',
 'pairs = matcher.knnMatch(queryDescriptors, trainDescriptors, k=2)', 'queryDescriptors|第一组描述子;trainDescriptors|第二组描述子；数据类型应匹配;k|每个查询点需要的候选数量', '嵌套 DMatch 列表；单组长度不一定足够 k。',
 '_, des = cv.SIFT_create().detectAndCompute(gray, None)\nif des is not None and len(des) >= 2:\n    matcher = cv.BFMatcher(cv.NORM_L2)\n    pairs = matcher.knnMatch(des, des, k=2)\n    good = [pair[0] for pair in pairs\n            if len(pair) == 2 and pair[0].distance < 0.75*pair[1].distance]\n    print(len(good))',
 '0.75 是常用经验比例，需按数据调整。|先检查每组长度再解包；没有描述子时不要调用匹配。', 'knnMatch K近邻 匹配 比率 筛选 Lowe', 'BFMatcher drawMatchesKnn findHomography')
entry('drawMatches','画出两图特征对应连线','匹配与配准','把两张图横向放置，并连接已匹配关键点。',
 'canvas = cv.drawMatches(img1, kp1, img2, kp2, matches, None)', 'kp1, kp2|两张图各自的关键点;matches|DMatch 的一维序列', '包含两张图和连线的合成图片。',
 'points, des = cv.SIFT_create().detectAndCompute(gray, None)\nif des is not None:\n    matches = cv.BFMatcher(cv.NORM_L2, crossCheck=True).match(des, des)\n    canvas = cv.drawMatches(img, points, img, points, matches[:20], None)\n    print(canvas.shape)',
 'knnMatch 返回嵌套列表，先筛成一维 good 列表，或改用 drawMatchesKnn。', '匹配 画线 连线 可视化', 'BFMatcher drawMatchesKnn')
entry('drawMatchesKnn','绘制嵌套候选匹配','匹配与配准','显示 knnMatch 返回的每组候选对应关系。',
 'canvas = cv.drawMatchesKnn(img1, kp1, img2, kp2, matches, None)', 'matches|由 DMatch 列表组成的嵌套列表，如 [[m], [m]]', '带匹配连线的图。',
 'points, des = cv.SIFT_create().detectAndCompute(gray, None)\nif des is not None and len(des) >= 2:\n    pairs = cv.BFMatcher(cv.NORM_L2).knnMatch(des, des, k=2)\n    good = [[p[0]] for p in pairs if len(p) == 2 and p[0].distance < 0.75*p[1].distance]\n    canvas = cv.drawMatchesKnn(img, points, img, points, good[:20], None)\n    print(canvas.shape)', aliases='匹配 连线 KNN 绘制', related='BFMatcher.knnMatch drawMatches')
entry('findHomography','从对应点估计单应矩阵','匹配与配准','估计两幅图中同一平面的坐标映射；RANSAC 可排除部分错误匹配。',
 'H, mask = cv.findHomography(srcPoints, dstPoints, cv.RANSAC, ransacReprojThreshold)',
 'srcPoints, dstPoints|对应的浮点坐标；至少四对且需非退化;method|RANSAC 是常用稳健估计方式;ransacReprojThreshold|内点判定的重投影误差阈值，通常以像素计',
 '3×3 矩阵及内点掩膜；估计失败 H 可能为 None。',
 'src = np.float32([[0,0], [100,0], [100,80], [0,80], [40,30], [75,50]])\ndst = src + np.float32([20, 15])\nH, inliers = cv.findHomography(src, dst, cv.RANSAC, 3.0)\nif H is not None:\n    print(H, "内点：", int(inliers.sum()))',
 '一般适用于平面或纯旋转等条件；不能任意消除三维场景的视差。|匹配点数量足够也不保证几何分布良好。', '单应 配准 RANSAC 拼接 对齐', 'perspectiveTransform warpPerspective BFMatcher.knnMatch')

entry('findChessboardCorners','寻找棋盘内角点','标定与三维','在标定图像中检测棋盘格内部交点。',
 'found, corners = cv.findChessboardCorners(gray, patternSize)', 'gray|棋盘图像;patternSize|每行、每列的内角点数 (列数, 行数)，不是格子数', '是否找到完整棋盘，以及角点坐标。',
 'found, corners = cv.findChessboardCorners(gray, (7, 7))\nif found:\n    canvas = cv.drawChessboardCorners(img.copy(), (7, 7), corners, found)\n    print("内角点数：", len(corners))\nelse:\n    print("未找到完整棋盘")',
 '8×8 个格子的内部通常有 7×7 个角点。|真实标定需多视角采集，并保持角点排序与世界坐标一致。', '棋盘 标定 内角点', 'cornerSubPix calibrateCamera')
entry('projectPoints','三维点投影到图像','标定与三维','根据相机内参、畸变和物体相对相机的位姿，将三维点投影成像素坐标。',
 'pixels, jacobian = cv.projectPoints(objectPoints, rvec, tvec, cameraMatrix, distCoeffs)',
 'objectPoints|三维点数组;rvec, tvec|世界或物体到相机的旋转向量和平移;cameraMatrix|3×3 内参矩阵;distCoeffs|畸变系数，None 表示不考虑',
 '二维投影点与雅可比矩阵。',
 'K = np.float64([[800,0,270], [0,800,180], [0,0,1]])\nxyz = np.float64([[0,0,5], [1,0,5], [0,1,5]])\npixels, _ = cv.projectPoints(xyz, np.zeros(3), np.zeros(3), K, None)\nprint(pixels.reshape(-1, 2))',
 '平移向量和三维点必须使用相同长度单位；结果是像素坐标。', '投影 相机 三维 二维 像素', 'calibrateCamera solvePnP Rodrigues')
entry('calibrateCamera','多视角相机标定','标定与三维','利用已知三维标定点与多张图像中的对应像素点，估计内参和畸变。',
 'rms, K, dist, rvecs, tvecs = cv.calibrateCamera(objectPoints, imagePoints, imageSize, None, None)',
 'objectPoints|每张图对应的三维点数组列表;imagePoints|每张图对应的二维角点列表;imageSize|图像 (宽, 高)', '重投影 RMS、内参、畸变和每张图的位姿。',
 '''# 人工生成多视角投影，仅演示接口，不是真实相机标定。
obj = np.zeros((9*6, 3), np.float32)
obj[:, :2] = np.mgrid[0:9, 0:6].T.reshape(-1, 2) * 0.03
known_K = np.float64([[800,0,270], [0,820,180], [0,0,1]])
objects, images = [], []
for i in range(12):
    r = np.float64([0.04+i*.018, -.2+i*.03, -.05+i*.008])
    t = np.float64([-.10+i*.004, -.08+i*.002, .7+i*.025])
    pts, _ = cv.projectPoints(obj, r, t, known_K, np.zeros(5))
    objects.append(obj.copy())
    images.append(pts.astype(np.float32))
rms, K, dist, rvecs, tvecs = cv.calibrateCamera(objects, images, (540,360), None, None)
print("RMS:", rms, "内参：", K)''',
 'imageSize 是 (宽, 高)，不是 shape 的 (高, 宽)。|真实标定应覆盖不同倾角与画面区域；RMS 小不单独保证真实精度。', '标定 内参 畸变 相机 calibration', 'findChessboardCorners cornerSubPix projectPoints undistort')
entry('undistort','去除镜头畸变','标定与三维','用已标定的相机内参和畸变系数校正图像。',
 'dst = cv.undistort(src, cameraMatrix, distCoeffs)', 'src|输入图;cameraMatrix|与当前图像尺寸匹配的内参;distCoeffs|标定得到的畸变系数', '去畸变图。',
 'K = np.float64([[800,0,270], [0,800,180], [0,0,1]])\ndist = np.float64([0.1, -0.05, 0, 0, 0])\ncorrected = cv.undistort(img, K, dist)\nprint(corrected.shape)',
 '示例参数只是演示；真实矫正必须使用真实标定结果。|缩放图像时需要同步调整内参中的焦距和主点。', '去畸变 校正 镜头 畸变', 'calibrateCamera')
entry('solvePnP','由三维二维对应点求位姿','标定与三维','在已知内参的情况下，用三维点与像素对应关系估计物体相对相机的姿态。',
 'ok, rvec, tvec = cv.solvePnP(objectPoints, imagePoints, K, dist)',
 'objectPoints|物体三维坐标;imagePoints|对应像素坐标;K, dist|相机内参和畸变', '成功标志、旋转向量和位移向量。',
 'K = np.float64([[800,0,270], [0,800,180], [0,0,1]])\nxyz = np.float64([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,1,1]])\npixels, _ = cv.projectPoints(xyz, np.zeros(3), np.float64([0,0,5]), K, None)\nok, rvec, tvec = cv.solvePnP(xyz, pixels, K, None)\nprint(ok, tvec.ravel())',
 '求得的是物体坐标到相机坐标的变换；相机在物体坐标中的位置需再求逆。|最少点数取决于算法和点的几何条件。', '位姿 PnP 相机 位置 姿态', 'projectPoints Rodrigues')
entry('Rodrigues','旋转向量与旋转矩阵互转','标定与三维','在 3 元旋转向量与 3×3 旋转矩阵之间转换。',
 'dst, jacobian = cv.Rodrigues(src)', 'src|3 元旋转向量或 3×3 旋转矩阵', '另一种表示形式与雅可比矩阵。',
 'rvec = np.float64([0, 0, np.pi/2])\nR, _ = cv.Rodrigues(rvec)\nrestored, _ = cv.Rodrigues(R)\nprint(R, restored.ravel())',
 '旋转向量的方向是旋转轴，长度是旋转角（弧度），不是三个欧拉角。', '旋转 罗德里格斯 向量 矩阵', 'solvePnP projectPoints')
entry('StereoSGBM_create','创建半全局双目视差匹配器','标定与三维','创建从已校正的左右图像估计视差的对象。',
 'matcher = cv.StereoSGBM_create(minDisparity=0, numDisparities=64, blockSize=5, ...)',
 'minDisparity|最小视差;numDisparities|搜索范围，需为 16 的倍数;blockSize|匹配块尺寸，取正奇数;P1, P2|视差平滑惩罚参数，通常 P2 大于 P1', 'StereoSGBM 对象。',
 '''# 人工平移的图像对，仅用于演示已知视差。
rng = np.random.default_rng(42)
left = rng.integers(0, 256, (128, 256), dtype=np.uint8)
right = np.zeros_like(left)
right[:, :-8] = left[:, 8:]
matcher = cv.StereoSGBM_create(minDisparity=0, numDisparities=32,
    blockSize=5, P1=8*25, P2=32*25)
disparity = matcher.compute(left, right).astype(np.float32) / 16.0
print(np.median(disparity[20:-20, 64:-20]))''',
 'compute 输出通常是放大 16 倍的有符号定点视差；做几何计算前应转浮点并除以 16。|真实双目图像需先完成标定和极线校正。', '双目 视差 立体 深度 SGBM', 'StereoSGBM.compute stereoRectify reprojectImageTo3D')
entry('triangulatePoints','由双视图对应点三角化','标定与三维','用两台相机的投影矩阵和对应二维点恢复齐次三维坐标。',
 'points4D = cv.triangulatePoints(P1, P2, points1, points2)',
 'P1, P2|3×4 投影矩阵；需与二维点采用同一坐标约定;points1, points2|2×N 浮点二维坐标', '4×N 齐次点；需除以最后一行得到三维坐标。',
 '''# 归一化相机坐标演示。
P1 = np.hstack((np.eye(3), np.zeros((3, 1))))
P2 = np.hstack((np.eye(3), np.float64([[-1], [0], [0]])))
p1 = np.float64([[0.0], [0.0]])
p2 = np.float64([[-0.2], [0.0]])
X = cv.triangulatePoints(P1, P2, p1, p2)
if abs(X[3, 0]) > 1e-12:
    print((X[:3] / X[3]).T)  # 约为 [0, 0, 5]''',
 '若投影矩阵不含内参，输入点通常需去畸变并归一化；不能混用像素与归一化坐标。|最后一行接近零时无法稳定转成有限三维点。', '三角化 三维 齐次 坐标 重建', 'projectPoints reprojectImageTo3D')
entry('reprojectImageTo3D','将视差图转为三维点图','标定与三维','根据双目校正得到的 Q 矩阵，把每个像素的视差映射成三维坐标。',
 'points3D = cv.reprojectImageTo3D(disparity, Q)',
 'disparity|真实像素视差，通常为 float32；SGBM 结果先除以 16;Q|stereoRectify 得到的 4×4 重投影矩阵', '高×宽×3 的坐标图；长度单位由标定中的尺度决定。',
 '''# 标准平行双目示例：f=800px，基线 B=0.1m。
f, B, cx, cy = 800.0, 0.1, 2.0, 2.0
Q = np.float64([[1,0,0,-cx], [0,1,0,-cy], [0,0,0,f], [0,0,1/B,0]])
disparity = np.full((5, 5), 20, np.float32)
xyz = cv.reprojectImageTo3D(disparity, Q)
print(xyz[2, 2])  # 约为 [0, 0, 4] 米''',
 '真实任务请使用自己 stereoRectify 输出的 Q，不要照抄示例矩阵。|应根据匹配器的无效视差标志及重建后的有限值筛除无效点。', '视差 深度 点云 三维 Q', 'StereoSGBM_create stereoRectify')

entry('line','绘制线段','绘图与视频','在图像上直接画一条线段。', 'cv.line(img, pt1, pt2, color, thickness=1)',
 'img|会被修改的画布;pt1, pt2|端点 (x, y);color|BGR 颜色;thickness|线宽；像素', '返回图像，同时修改输入画布。',
 'canvas = img.copy()\ncv.line(canvas, (20, 330), (500, 330), (0, 0, 255), 3)\nprint(canvas.shape)', aliases='绘图 线 线段', related='rectangle circle')
entry('rectangle','绘制矩形','绘图与视频','按两个角点在图像上画矩形。', 'cv.rectangle(img, pt1, pt2, color, thickness=1)',
 'pt1, pt2|两个角点坐标 (x, y);color|BGR 颜色;thickness|-1 表示填充', '返回图像，同时修改输入画布。',
 'canvas = img.copy()\ncv.rectangle(canvas, (250, 30), (500, 320), (0, 200, 0), 2)\nprint(canvas.shape)', aliases='矩形 框 包围盒 绘图', related='boundingRect line')
entry('circle','绘制圆','绘图与视频','按圆心和半径画圆形。', 'cv.circle(img, center, radius, color, thickness=1)',
 'center|圆心 (x, y);radius|半径，像素;color|BGR;thickness|-1 表示实心', '返回图像，同时修改输入画布。',
 'canvas = img.copy()\ncv.circle(canvas, (380, 130), 80, (0, 255, 0), 2)\nprint(canvas.shape)', aliases='圆 绘图 圆心 半径', related='line rectangle')
entry('polylines','绘制折线与多边形','绘图与视频','连接多个点，可选择首尾闭合。', 'cv.polylines(img, pts, isClosed, color, thickness=1)',
 'pts|点数组列表，常为 [points]；点用 int32;isClosed|是否闭合', '返回图像，同时修改输入画布。',
 'canvas = img.copy()\npoints = np.int32([[250, 50], [490, 100], [420, 300]])\ncv.polylines(canvas, [points], True, (0, 200, 0), 3)\nprint(canvas.shape)', aliases='折线 多边形 绘图', related='boxPoints drawContours')
entry('putText','在图像上绘制文字','绘图与视频','用内置字体把字符串画到图像上。', 'cv.putText(img, text, org, fontFace, fontScale, color, thickness=1)',
 'text|文字内容;org|文字基线左下起点 (x, y);fontFace|如 FONT_HERSHEY_SIMPLEX;fontScale|字体缩放比例;color|BGR 颜色', '返回图像，同时修改输入画布。',
 'canvas = img.copy()\ncv.putText(canvas, "Hello OpenCV", (20, 345), cv.FONT_HERSHEY_SIMPLEX,\n           0.8, (0, 0, 255), 2, cv.LINE_AA)\nprint(canvas.shape)',
 '内置 Hershey 字体不支持直接正确绘制中文；中文可考虑 Pillow 字体绘制。', '文字 文本 中文 字体 标注', 'line rectangle')
entry('VideoCapture','打开摄像头或视频','绘图与视频','创建读取摄像头或视频文件的对象。', 'cap = cv.VideoCapture(source)',
 'source|0 常表示默认摄像头；字符串通常为视频路径', 'VideoCapture 对象，需用 isOpened 检查是否成功。',
 '''cap = cv.VideoCapture(0)
try:
    if not cap.isOpened():
        raise RuntimeError("摄像头打开失败，请检查设备和权限")
    ok, frame = cap.read()
    if ok:
        cv.imshow("Camera", frame)
        cv.waitKey(0)
finally:
    cap.release()
    cv.destroyAllWindows()''',
 '此示例需要真实摄像头；它不是无硬件的合成示例。|退出时 release；先判断读取成功，再使用 frame。', '摄像头 视频 打开 拍照 capture', 'VideoCapture.read VideoCapture.release', True)
entry('VideoCapture.read','读取下一帧','绘图与视频','从已经打开的 VideoCapture 对象获取下一幅图像。', 'ok, frame = cap.read()',
 'cap|已打开的 VideoCapture 对象', '成功标志和图像；到视频末尾或读取失败时 ok 为 False。',
 '''cap = cv.VideoCapture(0)
try:
    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("未读到图像")
    print(frame.shape)
finally:
    cap.release()''', '必须先检查 ok，不能直接对失败的 frame 做 cvtColor。', '读取 帧 视频 摄像头', 'VideoCapture VideoCapture.release', True)
entry('PSNR','计算峰值信噪比','颜色与像素','用均方误差比较两幅图，常用于失真评价；数值越高通常代表逐像素越相近。',
 'score = cv.PSNR(src1, src2, R=255)', 'src1, src2|形状和类型相同的图;R|信号峰值，普通 8 位图常用 255', 'PSNR 数值，单位 dB。',
 'blurred = cv.GaussianBlur(img, (5, 5), 1)\nscore = cv.PSNR(img, blurred)\nprint("PSNR:", score)',
 '必须先对齐；它不等价于人眼主观质量。|当误差为零时，理论 PSNR 为正无穷；实际实现可能给出很大的有限值。', '峰值信噪比 误差 失真 MSE', 'absdiff')

CONSTANTS = [
 ('COLOR_BGR2GRAY','BGR 转灰度','颜色与像素','交给 cvtColor 的转换规则。','gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)','灰度 转换'),
 ('COLOR_BGR2RGB','BGR 转 RGB','颜色与像素','交换红蓝通道，常用于把 OpenCV 图送到按 RGB 解释的工具。','rgb = cv.cvtColor(img, cv.COLOR_BGR2RGB)','RGB BGR 转换'),
 ('COLOR_BGR2HSV','BGR 转 HSV','颜色与像素','将颜色分成色相、饱和度和明度；便于按颜色范围筛选。','hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)','HSV 颜色 色相'),
 ('IMREAD_COLOR','按彩色读取','读写与窗口','imread、imdecode 的彩色读取标志；输出通常为三通道 BGR。','ok, buf = cv.imencode(".png", img)\nloaded = cv.imdecode(buf, cv.IMREAD_COLOR)','彩色 读图'),
 ('IMREAD_GRAYSCALE','按灰度读取','读写与窗口','读取为单通道灰度图；与事后 cvtColor 的结果可能有细微差异。','ok, buf = cv.imencode(".png", img)\nloaded = cv.imdecode(buf, cv.IMREAD_GRAYSCALE)','灰度 读图'),
 ('THRESH_BINARY','普通二值化规则','阈值与形态学','像素严格大于阈值时设为 maxval，否则设为 0。','_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY)','阈值 二值'),
 ('THRESH_OTSU','自动选择全局阈值','阈值与形态学','与基础阈值类型合用，按图像直方图自动估计阈值。','used, binary = cv.threshold(gray, 0, 255, cv.THRESH_BINARY + cv.THRESH_OTSU)','Otsu 大津 自动阈值'),
 ('NORM_L2','欧氏距离','匹配与配准','BFMatcher 中常用来比较默认 SIFT 的浮点描述子。','matcher = cv.BFMatcher(cv.NORM_L2)','L2 欧氏 SIFT 距离'),
 ('NORM_HAMMING','汉明距离','匹配与配准','比较二进制描述子中不同位的数量；适用于默认 WTA_K=2 的 ORB。','matcher = cv.BFMatcher(cv.NORM_HAMMING)','汉明 ORB 二进制 距离'),
 ('INTER_LINEAR','双线性插值','几何变换','resize、warpAffine 等常用插值选项。','resized = cv.resize(img, (800, 533), interpolation=cv.INTER_LINEAR)','插值 线性 放大'),
 ('INTER_AREA','像素面积关系重采样','几何变换','缩小图像时常用的插值选项。','resized = cv.resize(img, (270, 180), interpolation=cv.INTER_AREA)','插值 面积 缩小'),
 ('RETR_EXTERNAL','只取最外层轮廓','边缘与轮廓','findContours 的轮廓检索方式，忽略内嵌轮廓。','_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\ncontours, _ = cv.findContours(binary, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)','轮廓 外层 检索'),
 ('CHAIN_APPROX_SIMPLE','压缩直线段的轮廓点','边缘与轮廓','保留轮廓形状所需的较少点；例如直线段主要保留端点。','_, binary = cv.threshold(gray, 100, 255, cv.THRESH_BINARY_INV)\ncontours, _ = cv.findContours(binary, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)','轮廓 简化 压缩'),
]
for name,title,cat,desc,code,aliases in CONSTANTS:
    entry(name,title,cat,desc,'cv.'+name,'','常量值；它是参数选项，不是可以加括号调用的函数。',code,
          '不要写成 cv.'+name+'()；将它作为其他函数的参数。',aliases)

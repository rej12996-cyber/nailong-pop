// 静态检查、真实查询数据检查和界面事件的 DOM 桩验证，不启动浏览器。
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(path.join(__dirname,'../OpenCV函数词典.html'),'utf8');
function script(id){const match=html.match(new RegExp('<script[^>]*id="'+id+'"[^>]*>([\\s\\S]*?)<\\/script>'));assert(match,'missing script '+id);return match[1]}
const data=JSON.parse(script('dictionary-data'));
const context=vm.createContext({});
vm.runInContext(script('search-core')+';this.core=DictCore;',context);
const core=context.core,entries=data.entries.map(core.prepare);
assert.equal(new Set(entries.map(e=>e.name)).size,entries.length);
for(const [q,name] of [['cv.imread','imread'],['cv2.imread','imread'],['IMREAD','imread'],['cv.GaussianBlur(img, (5, 5), 0)','GaussianBlur'],['cv2.Canny()','Canny'],['cv.SIFT.detectAndCompute','SIFT.detectAndCompute'],['cv.COLOR_BGR2GRAY','COLOR_BGR2GRAY']]){
 assert.equal(core.search(entries,q)[0]?.name,name,'query: '+q);
}
for(const [q,name] of [['灰度','cvtColor'],['高斯','GaussianBlur'],['图像配准','findHomography'],['中文路径','imdecode']]){
 assert(core.search(entries,q).slice(0,15).some(e=>e.name===name),'Chinese query: '+q);
}
assert(core.closest(entries,'cv.GausianBlur').some(e=>e.name==='GaussianBlur'));
assert.equal(core.search(entries,'this_api_does_not_exist_2026').length,0);
assert(core.search(entries,'','滤波与梯度','function',true).every(e=>e.category==='滤波与梯度'&&e.kind==='function'&&e.curated));
assert.equal(core.search(entries,'','favorites','all',false,new Set(['Canny'])).length,1);
assert.equal(core.search(entries,'cv.').length,entries.length);
assert(!/<(?:script|link|img|iframe)[^>]+(?:src|href)=["']https?:/i.test(html),'External runtime dependency');
assert(!/\b(?:fetch|XMLHttpRequest|WebSocket)\s*\(/.test(script('app-code')),'Unexpected network call');

class FakeElement{
 constructor(id){this.id=id;this.innerHTML='';this.textContent='';this.value='';this.checked=false;this.listeners={};this.dataset={};this.tagName='DIV';this.classList={add(){},remove(){},toggle(){}};this.style={};this.hidden=false;this.download='';}
 addEventListener(type,callback){this.listeners[type]=callback}
 querySelectorAll(){return []}
 focus(){document.activeElement=this} select(){} remove(){} click(){} append(){} setAttribute(){} scrollIntoView(){} showModal(){this.open=true} close(){this.open=false}
}
const elements=new Map();
const document={activeElement:{tagName:'BODY'},events:{},getElementById(id){if(!elements.has(id))elements.set(id,new FakeElement(id));return elements.get(id)},querySelectorAll(){return []},addEventListener(type,callback){this.events[type]=callback},createElement(tag){return new FakeElement(tag)},body:{append(){}},execCommand(){return true}};
document.getElementById('dictionary-data').textContent=script('dictionary-data');
const storage=new Map();
const sandbox={document,console,navigator:{clipboard:{async writeText(text){sandbox.copied=text}}},location:{hash:''},history:{replaceState(a,b,hash){sandbox.location.hash=hash}},localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},setTimeout:()=>1,clearTimeout(){},Blob,URL,window:{addEventListener(){}}};
vm.createContext(sandbox);vm.runInContext(script('search-core')+'\n'+script('app-code'),sandbox);
assert(document.getElementById('detail').innerHTML.includes('cv.imread'));
assert(document.getElementById('python-code').innerHTML.includes('imread'));
const input=document.getElementById('search');
input.value='cv.Canny';input.listeners.input({target:input});
assert(document.getElementById('detail').innerHTML.includes('提取细边缘'));
async function click(fields){await document.events.click({target:{closest:()=>({dataset:{},...fields})}})}
(async()=>{
 await click({dataset:{codeMode:'full'}});
 assert(document.getElementById('python-code').innerHTML.includes('自动生成演示图'));
 await click({id:'copy-code'});
 assert(sandbox.copied.includes('import cv2 as cv')&&sandbox.copied.includes('cv.Canny'));
 await click({id:'favorite'});
 assert(JSON.parse(storage.get('opencv-dictionary-favorites-v1')).includes('Canny'));
 await click({dataset:{category:'favorites'}});
 assert(document.getElementById('detail').innerHTML.includes('cv.Canny'));
 await click({dataset:{query:'cv.ThisDoesNotExist'}});
 assert(document.getElementById('results').innerHTML.includes('没有找到匹配词条'));
 await click({dataset:{reset:'true'}});
 assert(document.getElementById('results').innerHTML.includes('data-entry'));
 input.value='cv.Sobel';input.listeners.input({target:input});
 await click({id:'download-code'});
 assert(document.getElementById('toast').textContent.includes('已生成'));
 console.log(JSON.stringify({entries:entries.length,curated:data.meta.curated,search:'PASS',offline_static:'PASS',ui_event_stub:'PASS',browser_visual:'NOT_RUN'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});

"""执行非交互中文示例；交互例子只做语法检查，不启用摄像头。"""
import contextlib
import io
import json
import os
from pathlib import Path
from curated import ENTRIES, PREAMBLE

work=Path(__file__).resolve().parents[3]/'tmp'/'dictionary_example_check'
work.mkdir(parents=True,exist_ok=True)
os.chdir(work)
failures=[]
passed=[]
skipped=[]
for item in ENTRIES:
    try:
        compiled=compile(PREAMBLE+item['code'],item['name'],'exec')
        if item['interactive']:
            skipped.append(item['name'])
            continue
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compiled,{})
        passed.append(item['name'])
    except Exception as exc:
        failures.append({'name':item['name'],'error':str(exc)})
report={'passed':len(passed),'skipped_interactive':skipped,'failures':failures}
(work/'examples-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(bool(failures))
